<?php 
	session_start();
 
	// cek apakah yang mengakses halaman ini sudah login
	if($_SESSION['level']==""){
		header("location:../index.php?pesan=gagal");
	}
 
	?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Administrator</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>

    <div class="container">
         <div class="content">
              <div class="card mt-5">
                   <div class="card-body">
                       <a href="index.php" class="btn btn-success">Beranda</a>
                       <a href="data_barang.php" class="btn btn-success">Data Barang</a>
                       <a href="pembelian.php" class="btn btn-success">Pembelian</a>
                       <a href="stok_barang.php" class="btn btn-success">Stok Barang</a>
                       <a href="data_pengguna.php" class="btn btn-success">Data Pengguna</a>
                       <a href="../logout.php" class="btn btn-danger">Keluar</a>
                   </div>
              </div>
              <div class="card mt-2">
                   <div class="card-body">
                        <div class="row">
                             <div class="col-sm-3">
                                 <div class="card">
                                      <div class="card-body">
                                           Data Barang
                                           <?php
						             include '../koneksi.php';
						             $data_produk = mysqli_query($koneksi,"SELECT * FROM produk");
						             $jumlah_produk = mysqli_num_rows($data_produk);
                                           ?>
                                           <h3><?php echo $jumlah_produk; ?></h3>
						             <a href="data_barang.php" class="btn btn-outline-primary btn-sm">Detail</a>
                                        </div>
                                   </div>
                              </div>         
                               <div class="col-sm-3">
				               <div class="card">
					                <div class="card-body">
						            Data Pembelian
						            <?php
						            include '../koneksi.php';
						            $data_penjualan = mysqli_query($koneksi,"SELECT * FROM penjualan");
						            $jumlah_penjualan = mysqli_num_rows($data_penjualan);
						            ?>
						            <h3><?php echo $jumlah_penjualan; ?></h3>
						            <a href="pembelian.php" class="btn btn-outline-primary btn-sm">Detail</a>
					               </div>
				               </div>
			               </div>
                             <div class="col-sm-3">
                                 <div class="card">
                                      <div class="card-body">
                                           Stok Barang
                                           <?php
						            include '../koneksi.php';
						            $data_produk = mysqli_query($koneksi,"SELECT * FROM produk");
						            $jumlah_produk = mysqli_num_rows($data_produk);
						            ?>
						            <h3><?php echo $jumlah_produk; ?></h3>
                                          <a href="stok_barang.php" class="btn btn-outline-primary btn-sm">Detail</a>
                                      </div>
                                 </div>
                             </div>
                             <div class="col-sm-3">
                                 <div class="card">
                                      <div class="card-body">
                                           Data Pengguna
                                           <?php
						            include '../koneksi.php';
						            $data_petugas = mysqli_query($koneksi,"SELECT * FROM petugas");
						            $jumlah_petugas = mysqli_num_rows($data_petugas);
						            ?>
						            <h3><?php echo $jumlah_petugas; ?></h3>
                                          <a href="data_pengguna.php" class="btn btn-outline-primary btn-sm">Detail</a>
                                      </div>
                                 </div>
                             </div>
                        </div>
                   </div>
              </div>
         </div>
    </div>
	<h1>Halaman Admin</h1>
 
	<p>Halo <b><?php echo $_SESSION['username']; ?></b> Anda telah login sebagai <b><?php echo $_SESSION['level']; ?></b>.</p>
	<a href="../logout.php">LOGOUT</a>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
</body>
</html>